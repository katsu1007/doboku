import SwiftUI
import WebKit
import UIKit

@main
struct DobokuApp: App {
    var body: some Scene {
        WindowGroup {
            WebView()
                .ignoresSafeArea()
        }
    }
}

/// 拾い出しの内容と単価をこの携帯の中に保存する
final class Store: NSObject, WKScriptMessageHandler {
    static let key = "doboku-state"
    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        if let json = message.body as? String {
            UserDefaults.standard.set(json, forKey: Store.key)
        }
    }
}

/// CSVをファイルにして、共有メニュー（ファイルに保存・LINE・AirDropなど）を出す
final class Sharer: NSObject, WKScriptMessageHandler {
    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let dict = message.body as? [String: Any],
              let name = dict["name"] as? String,
              let text = dict["text"] as? String else { return }
        let safeName = name.replacingOccurrences(of: "/", with: "_")
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(safeName)
        do {
            try text.write(to: url, atomically: true, encoding: .utf8)
        } catch {
            return
        }
        DispatchQueue.main.async {
            let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
            guard let window = scenes.flatMap({ $0.windows }).first(where: { $0.isKeyWindow }) ?? scenes.first?.windows.first,
                  var top = window.rootViewController else { return }
            while let presented = top.presentedViewController { top = presented }
            let sheet = UIActivityViewController(activityItems: [url], applicationActivities: nil)
            sheet.popoverPresentationController?.sourceView = top.view
            top.present(sheet, animated: true)
        }
    }
}

/// 材料表をクリップボードにコピーする
final class Copier: NSObject, WKScriptMessageHandler {
    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        if let text = message.body as? String { UIPasteboard.general.string = text }
    }
}

/// ネットのリンクはアプリの外（Safari）で開く
final class LinkOpener: NSObject, WKNavigationDelegate, WKUIDelegate {
    private func openOutside(_ url: URL?) -> Bool {
        guard let url = url, let scheme = url.scheme?.lowercased(), scheme == "http" || scheme == "https" else { return false }
        UIApplication.shared.open(url)
        return true
    }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if openOutside(navigationAction.request.url) { decisionHandler(.cancel) } else { decisionHandler(.allow) }
    }
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        _ = openOutside(navigationAction.request.url)
        return nil
    }
}

struct WebView: UIViewRepresentable {
    let store = Store()
    let sharer = Sharer()
    let copier = Copier()
    // リンク係はSwiftUIに持っておいてもらう（弱い参照で消えないように）
    func makeCoordinator() -> LinkOpener { LinkOpener() }

    func makeUIView(context: Context) -> WKWebView {
        let controller = WKUserContentController()
        controller.add(store, name: "store")
        controller.add(sharer, name: "share")
        controller.add(copier, name: "copy")

        // 前回の内容をページが読み込まれる前に渡す
        let saved = UserDefaults.standard.string(forKey: Store.key) ?? "null"
        let script = WKUserScript(source: "window.__nativeState = \(saved);",
                                  injectionTime: .atDocumentStart,
                                  forMainFrameOnly: true)
        controller.addUserScript(script)

        let config = WKWebViewConfiguration()
        config.userContentController = controller

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.isOpaque = false
        webView.backgroundColor = .systemBackground
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator

        if let url = Bundle.main.url(forResource: "index", withExtension: "html") {
            webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        }
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}
